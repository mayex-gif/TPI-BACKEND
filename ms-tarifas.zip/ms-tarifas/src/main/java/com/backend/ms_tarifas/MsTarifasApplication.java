package com.backend.ms_tarifas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsTarifasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsTarifasApplication.class, args);
	}

}
