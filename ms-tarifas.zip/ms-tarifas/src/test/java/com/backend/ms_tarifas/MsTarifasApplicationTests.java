package com.backend.ms_tarifas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsTarifasApplicationTests {

	@Test
	void contextLoads() {
	}

}
