package com.backend.ms_logistica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsLogisticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
